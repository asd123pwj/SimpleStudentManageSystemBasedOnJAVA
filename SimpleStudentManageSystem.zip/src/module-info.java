module javaClassPratice {
}